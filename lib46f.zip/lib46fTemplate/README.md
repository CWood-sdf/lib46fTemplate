# lib46fTemplate

This repository is a template repository for using lib46f in your program. All the PID default values are already in place. 

## Usage

Download the latest release from the [releases](https://github.com/CWood-sdf/lib46fTemplate/releases) page. If you are on windows, download the lib46fTemplate.zip file, if you are on mac or linux, download the lib46fTemplate.xz or the lib46fTemplate.7z file. 