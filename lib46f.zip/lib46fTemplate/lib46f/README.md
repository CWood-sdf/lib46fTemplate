# 46F
This project is the main program for 46X

It contains many parts

<h1>Wheelbase controls</h1>
<h2>Pure Pursuit</h2>
Use pure pursuit to control the robot along curve paths
<h2>Ramsete</h2>
Also use ramsete to move the robot along curves
<h2>PID</h2>
Use a basic PID loop to move the robot in straight lines
<h1>Sensors</h1>
<h2>Line Tracker</h2>
Uses line tracker for detection of close objects
<h2>Distance sensor</h2>
Kalmanized distance sensor
<h2>Potentiometer</h2>
Integrated potentiometer auton selection
<h1>Brain Screen</h1>
Has windows loader, data output, and auton selector. Any function can be plugged in, including those written with lvgl or regular Brain.Screen.draw[Name] controls
<h1>Future</h1>
<h2>Vision</h2>
EMA Filtering of vision objects
