﻿#include "stuff.h"
void testConnection(bool);
